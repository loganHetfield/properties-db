
$executingScript = $MyInvocation.MyCommand.Path
$executingScriptPath = split-path $executingScript
$executingScriptName = $MyInvocation.MyCommand.Name
Write-host -NoNewline -ForegroundColor DarkGray "script: "
Write-Host -ForegroundColor DarkGreen $executingScript

function target
{
    [CmdletBinding()]
    param( $name, $depends = @() )
    try
    {
        if( !( $script:targetDefs ) )
        {
            Write-Host -ForegroundColor DarkGray "Initializing target definitions:"
            $script:targetDefs = @{}
        }

        if( $script:targetDefs.ContainsKey( $name ) ){ throw( "Duplicate target exists [$name]." ); exit 1 }
        $script:targetDefs.Add( $name, $depends )
        Write-Host -NoNewline -ForegroundColor DarkGray "Target defined: ["
        Write-Host -NoNewline -ForegroundColor DarkGreen $name
        Write-Host -NoNewline -ForegroundColor DarkGray "] -depends "
        Write-Host -ForegroundColor DarkGreen $depends
    }
    catch{ $script:targetDefs = $null; Write-Error $_; exit 1; }
}

function evaluateDeferredExpressions
{
    [CmdletBinding()]
    param( [hashtable] $settings )

    $keys = $settings.Keys | % { $_ }
    $attempts = 0
    while( $attempts -lt 5 -and ( containsDeferredExpressions $settings ) )
    {
        foreach( $key in $keys )
        {
            $value = $settings[ $key ]
            if( valueContainsDeferredExpressions $value )
            {
                $value = Invoke-Expression "`"$value`""
                $settings[ $key ] = $value
            }
        }
        $attempts++
    }
}

function valueContainsDeferredExpressions
{
    [CmdletBinding()]
    param( $text )

    $text -is [string] -and $text -like '*$($*)*'
    return
}

function containsDeferredExpressions
{
    [CmdletBinding()]
    param( [hashtable] $settings )
    $keys = $settings.Keys | % { $_ }

    foreach( $key in $keys )
    {
        $value = $settings[ $key ]
        if( valueContainsDeferredExpressions $value )
        {
            $true
            return
        }
    }
}

function localizeSettings
{
    #settings prioritization from lowest to highest:
    #   common settings
    #   build target settings
    #   script settings
    [CmdletBinding()]
    param( $task, [hashtable] $settings = $null, [hashtable] $localized, $keepScriptSettings = $true )

    if( $settings -eq $null -or $settings.Length -eq 0 ) { return; }

    $scriptSettingKeys = $settings.Keys | where { $_ -like '*.ps1' }
    $targetSettingKeys = $settings.Keys | where { $_ -match "\[.*\].*" }
    $commonKeys = $settings.Keys | where { $scriptSettingKeys -cnotcontains $_ -and $targetSettingKeys -cnotcontains $_ }

    applySettings -existing $localized -settings $settings -keys $commonKeys

    #this statement looks for keys that exactly match "[$target]"
    $targetKeyMatch = $targetSettingKeys | where { $_ -eq "[$task]" }
    if( $targetKeyMatch -ne $null )
    {
        write-host "Applying task settings [$task]"
        $inner = $settings[ $targetKeyMatch ]
        applySettings -existing $localized -settings $inner
    }

    #this statement looks for keys that match the format "[$target]property"
    $targetKeyInlineMatches = $targetSettingKeys | where { $_ -match "\[$task\].+" }
    if( $targetKeyInlineMatches -ne $null )
    {
        write-host "Applying task settings [$task]property"
        applySettings -existing $localized -settings $settings -keys $targetKeyInlineMatches -keyTransform { param ( $key ) $key -replace "\[$task\]", '' }
    }

    $scriptSettingKeyMatch = $scriptSettingKeys | where { $task -isnot [scriptblock] -and $_ -imatch "^$task`$" }
    if( $scriptSettingKeyMatch -eq $null -and $keepScriptSettings -and $scriptSettingKeys -ne $null )
    {
        write-host "Applying but not resolving script settings."
        applySettings -existing $localized -settings $settings -keys $scriptSettingKeys
        return
    }

    if( $scriptSettingKeyMatch -eq $null ) { return }

    if( $scriptSettingKeyMatch -isnot [string] -and $scriptSettingKeyMatch.Count -gt 1 )
    {
        throw ("Ambiguous script settings detected: $scriptSettingKeyMatch");
        exit 1;
    }

    $scriptSettings = $settings[ $scriptSettingKeyMatch ]
    if( $scriptSettings -isnot [hashtable] ) { throw ( "Settings for scripts must be specified using a hashtable [$scriptSettingKeyMatch]." ); exit 1; }

    write-host "Applying script settings $scriptSettingKeyMatch"
    applySettings -existing $localized -settings $scriptSettings
}

function convertToHashtable( $target )
{
    if( $target -is [string] ){ $target = ConvertFrom-Json $target }
    elseif( $target -isnot [pscustomobject] ){ throw ( "Expected a json object as a string or a PSCustomObject." ); exit 1; }
    $result = @{}
    $target | Get-Member -MemberType NoteProperty | % {
        $value = $($target.($_.Name))
        if( $value -is [pscustomobject] )
        {
            $value = convertToHashtable $value
        }
        $result.Add( $_.Name, $value ) > $null
    }
    $result
}

function applySettings
{
    [CmdletBinding()]
    param( $existing, $settings, [string[]] $keys = $null, [scriptblock] $keyTransform = { param( $key ) $key } )

    if( $keys -eq $null ){ $keys = $settings.Keys }

    foreach( $key in $keys )
    {
        if( $settings.Keys -cnotcontains $key ) { continue }

        $value = $settings[ $key ]
        $transformedKey = . $keyTransform $key

        if( $value -is [hashtable] )
        {
            $existingValue = @{}
            if( $existing.Keys -ccontains $transformedKey -and $existing[ $transformedKey ] -is [hashtable] )
            {
                $existingValue = $existing[ $transformedKey ]
            }

            applySettings -existing $existingValue -settings $value -keyTransform $keyTransform
            $value = $existingValue
        }

        if( $existing.Keys -ccontains $transformedKey ){ $existing[ $transformedKey ] = $value }
        else{ $existing.Add( $transformedKey, $value ) }
    }
}

function loadSettingsFromFile( $settingsFile )
{
    if( $settingsFile -eq $null ) { return; }

    if( !( test-path( $settingsFile ) ) )
    {
        throw( "Unable to locate the settings file $settingsFile" )
        exit 1
    }

    $existing = $script:settings

    Write-Host -NoNewline -ForegroundColor DarkGray "Applying settings file ["
    Write-Host -NoNewline -ForegroundColor DarkGreen $settingsFile
    Write-Host -NoNewline -ForegroundColor DarkGray "] "
    $extension = [system.IO.path]::GetExtension( $settingsFile )
    if ( $extension -eq '.ps1' ){
        . $settingsFile
    }
    else {
        $content = Get-Content $settingsFile
        if( $content -notlike '{*}' )
        {
            throw( "Unable to interpret settings file $settingsFile. Expected a json structure." )
            exit 1
        }

        $script:settings = convertToHashtable $content
    }

    if( $existing -ne $null )
    {
        $settings = $script:settings
        applySettings $existing $settings
        $script:settings = $existing
    }

    Write-Host -ForegroundColor DarkGray "complete"
}

function searchForSettingsFiles( $settingsSearchPath, $pattern )
{
    if( $settingsSearchPath -eq $null ){ return; }

    $searchPath = Join-Path $settingsSearchPath $pattern
    $dotsInPattern = 0
    for($i = 0; $i -lt $pattern.Length; $i++ ){ if( $pattern[$i] -eq '.' ) { $dotsInPattern++; } };

    Write-Host -NoNewline -ForegroundColor DarkGray "Searching for settings files matching ["
    Write-Host -ForegroundColor DarkGreen $searchPath
    $matches = dir $searchPath -Recurse | ? { $dotsInMatch = 0; for($i = 0; $i -lt $_.Name.Length; $i++ ){ if( $_.Name[$i] -eq '.' ) { $dotsInMatch++; } }; $dotsInPattern -eq $dotsInMatch; }
    if( $matches -eq $null )
    {
        Write-Host -NoNewline -ForegroundColor DarkGray "No settings files found matching ["
        Write-Host -ForegroundColor DarkGreen $searchPath
        return;
    }

    foreach( $file in $matches )
    {
        loadSettingsFromFile $file.FullName
    }
}

function initSettings
{
    param( $settingsFile = $null, [hashtable] $settings, $settingsSearchPath, $settingsPrefix )

	if (!$settingsPrefix)
	{
		throw("`$settingsPrefix is required. Verify that your settings files are correctly configured.");
		exit 1;
	}

    #load settings from file or look for a settings file
    if( $settingsFile -ne $null ) { loadSettingsFromFile $settingsFile; }
    else{ searchForSettingsFiles $settingsSearchPath "*\$settingsPrefix.*" }

    if( $script:settings -eq $null )
    {
        $script:settings = @{}
    }

    if( $settings -ne $null )
    {
        applySettings $script:settings $settings
    }

    #Look for server settings files based on the server
    if( $script:settings.Keys -icontains 'server' )
    {
        $server = $script:settings.server
        searchForSettingsFiles $settingsSearchPath "*\$settingsPrefix.$server.*"
    }

    #Look for environment settings files based on the environment
    if( $script:settings.Keys -icontains 'environment' )
    {
        $environment = $script:settings.environment
        searchForSettingsFiles $settingsSearchPath "*\$settingsPrefix.$environment.*"

        #Look for environment.server settings files based on the server
        if( $script:settings.Keys -icontains 'server' )
        {
            $server = $script:settings.server
            searchForSettingsFiles $settingsSearchPath "*\$settingsPrefix.$environment.$server.*"
        }
    }

    #Reload the localized settings hashtable with up-to-date values.
    #Here after we treat the $script:settings hashtable as the unmodified settings definition.
    #The values should never be accessed directly, or modified. Use the localized settings parameter
    #defined in each function.
    if( $script:settings.Length -ne 0 )
    {
        $settings.Clear();
        applySettings $settings $script:settings

        Write-Host -ForegroundColor DarkGray "Settings loaded: "
        $settings
        Write-Host ''
    }
}

function realizeScriptDependency
{
    param( $script, $scriptsSearchPath )

    if( Test-Path $script ){ $script; return; }

    Write-Host -NoNewline -ForegroundColor DarkGray "Searching for script "
    Write-Host -NoNewline -ForegroundColor DarkGreen $script
    Write-Host -NoNewline -ForegroundColor DarkGray " in "
    Write-Host -ForegroundColor DarkGreen $scriptsSearchPath

    $searchPath = Join-Path $scriptsSearchPath "*\$script"
    $matches = dir $searchPath -Recurse
    if( $matches -eq $null -or $matches.Length -eq 1  ){ throw ( "Unable to locate script in the current directory by the name of $script" ); exit 1; }
    if( $matches.Count -gt 1 ){ throw ( "Multiple scripts by with the name $script were found: $matches" ); exit 1; }
    $matches.FullName
    Write-Host -NoNewline -ForegroundColor DarkGray "Located script "
    Write-Host -NoNewline -ForegroundColor DarkGreen $script
    Write-Host -NoNewline -ForegroundColor DarkGray " at "
    Write-Host -ForegroundColor DarkGreen $matches.FullName
}

function execTask
{
    [CmdletBinding()]
    param( $task, [hashtable] $settings = $null, $scriptsSearchPath )

    Write-Host -NoNewline -ForegroundColor DarkGray "Executing task "
    write-Host -ForegroundColor DarkGreen "[$task]"

    $localized = @{}
    localizeSettings  -task $task -settings $settings -localized $localized -keepScriptSettings $false
    evaluateDeferredExpressions $localized
    Write-Host -ForegroundColor DarkGray "Settings: "
    $localized
    Write-Host ''

    $realized = $task
    if( $task -is [string] -and $task.Trim().EndsWith( ".ps1" ) )
    {
        $realized = realizeScriptDependency $task $scriptsSearchPath
    }

    . $realized @localized
    if( !$? ) {
        Write-Host -NoNewline -ForegroundColor DarkRed "Error detected in task "; write-Host -ForegroundColor DarkGreen "[$task]"; exit 1;
    }

    Write-Host -NoNewline -ForegroundColor DarkGray "Execution of task "
    write-Host -NoNewline -ForegroundColor DarkGreen "[$task]"
    Write-Host -NoNewline -ForegroundColor DarkGray ": "
    write-Host -ForegroundColor DarkGreen "complete"
}

function execTarget
{
    [CmdletBinding()]
    param( $target, $dependencies, [hashtable] $settings, $scriptsSearchPath )
    Write-Host -NoNewline -ForegroundColor DarkGray "Executing target "
    Write-Host -ForegroundColor DarkGreen "[$target]"

    $localized = @{}
    localizeSettings -task $target -settings $settings -localized $localized -keepScriptSettings $true
    if( $localized.Length -gt 0 )
    {
        Write-Host -ForegroundColor DarkGray "Settings: "
        $localized
        Write-Host ''
    }

    $success = $false

    foreach( $dependency in $dependencies )
    {
        if( !( $dependency -is [string] ) )
        {
            execTask $dependency -settings $localized -scriptsSearchPath $scriptsSearchPath
            $success = $?
            if( !$success ){ break; }
            continue
        }

        $dependencyIsTarget = $script:targetDefs.ContainsKey( $dependency )
        if( $dependencyIsTarget )
        {
            $innerDependencies = $script:targetDefs[ $dependency ]
            execTarget -target $dependency -dependencies $innerDependencies -settings $script:settings -scriptsSearchPath $scriptsSearchPath
            $success = $?
            if( !$success ){ break; }
            continue
        }

        execTask $dependency -settings $localized -scriptsSearchPath $scriptsSearchPath
        $success = $?
        if( !$success ){ break; }
    }

    if( !$success ) {
        Write-Host -NoNewline -ForegroundColor DarkRed "Error detected in target "; write-Host -ForegroundColor DarkGreen "[$target]"; exit 1;
    }
    Write-Host -NoNewline -ForegroundColor DarkGray "Execution of target "
    write-Host -NoNewline -ForegroundColor DarkGreen "[$target]"
    Write-Host -NoNewline -ForegroundColor DarkGray ": "
    write-Host -ForegroundColor DarkGreen "complete"
}

function build
{
    [CmdletBinding()]
    param( $target = $null, $settingsFile = $null, [hashtable] $settings = $null, $scriptsSearchPath = ".", $settingsSearchPath = ".", $settingsPrefix = 'settings' )

    try{
        $dependencies = $script:targetDefs[ $target ]
        if( $dependencies -eq $null ) { throw ( "build target '$target' was not recognized." ); exit 1; }

        initSettings $settingsFile $settings $settingsSearchPath $settingsPrefix
        execTarget -target $target -dependencies $dependencies -settings $settings -scriptsSearchPath $scriptsSearchPath
    }
    catch
    {
        Write-Host -ForegroundColor DarkRed $_
        Write-Host -ForegroundColor DarkRed  "---------------------- Call Stack: ----------------------"
        Write-Host -ForegroundColor DarkRed $_.ScriptStackTrace
        exit 1
    }
    finally
    {
        $script:targetDefs = $null;
        $script:settings = $null;
    }
}