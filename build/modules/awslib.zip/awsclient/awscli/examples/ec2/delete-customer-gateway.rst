**To delete a customer gateway**

This example deletes the specified customer gateway.

Command::

  aws ec2 delete-customer-gateway --customer-gateway-id cgw-0e11f167

Output::

  {
      "return": "true"
  }