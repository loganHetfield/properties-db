**To deregister an AMI**

This example deregisters the specified AMI.

Command::

  aws ec2 deregister-image --image-id ami-4fa54026

Output::

  {
      "return": "true"
  }