**To disassociate a route table**

This example disassociates the specified route table from the specified subnet.

Command::

  aws ec2 disassociate-route-table --association-id rtbassoc-781d0d1a

Output::

  {
      "return": "true"
  }